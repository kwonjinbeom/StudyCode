package com.spring.jbPortfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JbPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
